package com.springmvc.springmongodbweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringMongodbWebApplicationTests {

	@Test
	public void contextLoads() {
	}

}
